#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define MAX_LINE 256

int main(void) {
    char filename[100];
    FILE *fp;
    char buffer[MAX_LINE];

    printf("Enter the filename to read: ");
    if (fgets(filename, sizeof(filename), stdin) == NULL) {
        perror("Error reading filename");
        return EXIT_FAILURE;
    }

    filename[strcspn(filename, "\n")] = '\0';

    fp = fopen(filename, "r");
    if (fp == NULL) {
        perror("File opening failed");
        return EXIT_FAILURE;
    }

    printf("\nContents of %s:\n", filename);

    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        printf("%s", buffer);
    }

    if (ferror(fp)) {
        perror("Error reading file");
        fclose(fp);
        return EXIT_FAILURE;
    }

    fclose(fp);
    return EXIT_SUCCESS;
}
